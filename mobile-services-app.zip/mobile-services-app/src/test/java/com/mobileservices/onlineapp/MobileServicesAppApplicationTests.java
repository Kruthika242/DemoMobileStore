package com.mobileservices.onlineapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileServicesAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
