package com.mobileservices.onlineapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileServicesAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileServicesAppApplication.class, args);
	}

}
