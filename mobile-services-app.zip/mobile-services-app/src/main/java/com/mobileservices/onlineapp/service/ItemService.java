package com.mobileservices.onlineapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobileservices.onlineapp.entity.ItemEntity;
import com.mobileservices.onlineapp.entity.OrderEntity;
import com.mobileservices.onlineapp.repository.ItemRepository;

@Service
public class ItemService {
	
	@Autowired
	ItemRepository itemRepo;
	
	public List<ItemEntity> getAllItems(){
		List<ItemEntity> items=new ArrayList<ItemEntity>();
		itemRepo.findAll();
		return items;
	}
	
	public ItemEntity getItemByModel(int model) {
		return itemRepo.findById(model).get();	
	}
	
	
	/*public void addProduct(String itemname, String color, float price, String features, 
			int productid,int categoryid,int quantityavailable) {
		itemRepo.save(new ItemEntity(itemname,color,price,features,productid,categoryid,quantityavailable));
    }*/
	
	
	public void saveItem(ItemEntity item) {
        itemRepo.save(item);
    }
	
	/*public void delete(int model) {
        itemRepo.deleteById(model);
    }*/
	
	public void deleteItem(int model) {
		Optional<List<ItemEntity>> item=Optional.of(itemRepo.findByModel(model));
		if(item.isPresent()) {
			itemRepo.delete((ItemEntity) item.get());;
		}
    }
	
	
	
	
	
	
	public void updateItem(ItemEntity items) {
		itemRepo.save(items);
	}

}
