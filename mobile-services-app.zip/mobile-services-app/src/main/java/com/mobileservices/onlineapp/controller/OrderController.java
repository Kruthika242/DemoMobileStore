package com.mobileservices.onlineapp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mobileservices.onlineapp.entity.ItemEntity;
import com.mobileservices.onlineapp.entity.OrderEntity;
import com.mobileservices.onlineapp.repository.ItemRepository;
import com.mobileservices.onlineapp.repository.OrderRepository;
import com.mobileservices.onlineapp.service.ItemService;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import com.mobileservices.onlineapp.service.OrderService;

@Controller
public class OrderController {
	@Autowired
	private ItemRepository itemRepo;

	@Autowired
	OrderService orderService;

	@Autowired
	ItemService itemService;
	
	@Autowired
	HttpServletRequest request;

	@RequestMapping(value = { "/", "/adminlogin" })
	public String adminLogin() {
		return "adminlogin";
	}
	
	@RequestMapping("/logout")
	public String adminLogout() {
		return "logout";
	}

	// Show All Orders
	@RequestMapping("/orders")
	public String home(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Orders list.");
		model.addAttribute("orders", orderService.getAllOrders());
		return "orders";
	}

	@RequestMapping("/products")
	public String producthome(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Products list.");
		model.addAttribute("products", itemService.getAllItems());
		return "products";
	}
	
	
	@RequestMapping("/addproduct")
	public String add() {
		return "addproduct";
	}
	
	@RequestMapping(value = "delete/{model}", method = RequestMethod.GET)
	public String delete(@PathVariable("model") int model,Model mod) {
		System.out.println(model);
		itemService.deleteItem(model);
		mod.addAttribute("products", itemService.getAllItems());
		return "products";
	}
	
	@RequestMapping(value = "/saveitem", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("item") ItemEntity item,Model mod) {
		itemService.saveItem(item);
		mod.addAttribute("products", itemService.getAllItems());
		return "products";
	}
	
	@RequestMapping("/update/{model}")
	public String updateProduct(int model) {
		return "update";
	}
	
	/*@RequestMapping(value = "/savep", method = {RequestMethod.POST,RequestMethod.GET}) 
	public String updateItem(@ModelAttribute("product") ItemEntity item) {
			  itemService.saveItem(item); 
			  return "products";
			 }*/
	
	@RequestMapping(value = "/savep", method = RequestMethod.GET)
    public String updatePage(@RequestParam int model, ModelMap mod) {
		ItemEntity item=itemService.getItemByModel(model);
		mod.put("product", item);
        return "item";
    }
	
	@RequestMapping(value = "/savep", method = RequestMethod.POST)
    public String updateTodo(ModelMap mod,ItemEntity item) {
       itemService.saveItem(item);
       mod.addAttribute("products", itemService.getAllItems());
        return "products";
    }
	
	

	/*@RequestMapping("/updates/{model}")
	public ModelAndView showEditProductPage( @PathVariable("model") int model, 
			@PathVariable( "itemname") String itemname,
			@PathVariable( "color") String color,
			@PathVariable("price") float price,
			@PathVariable("features") String features,
			@PathVariable("productid") int productid,
			@PathVariable("categoryid") int categoryid,
			@PathVariable("quantityavailable") int quantityavailable) {
		ItemEntity item = new ItemEntity(model,features,quantityavailable);
		itemService.saveItem(item);
		ModelAndView mav = new ModelAndView("update");
		mav.addObject("product", itemRepo.findAll());
		return mav;
	}*/

	/*
	 * @RequestMapping(value = "/update", method =
	 * {RequestMethod.POST,RequestMethod.GET}) public String
	 * updateItem(@ModelAttribute("product") ItemEntity item) {
	 * itemService.saveItem(item); 
	 * return "products"; }
	 */



	@GetMapping("/product/{model}")
	private ItemEntity getItems(@PathVariable("model") int model) {
		return itemService.getItemByModel(model);
	}

	/*
	 * @PutMapping("/updateproduct") private ItemEntity updateItem(@RequestBody
	 * ItemEntity items) { itemService.updateItem(items); return items; }
	 */

}
