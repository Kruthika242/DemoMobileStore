package com.mobileservices.onlineapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mobileservices.onlineapp.entity.ItemEntity;
import com.mobileservices.onlineapp.entity.OrderEntity;
import com.mobileservices.onlineapp.repository.OrderRepository;
import com.mobileservices.onlineapp.service.ItemService;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.mobileservices.onlineapp.service.OrderService;

@Controller
public class OrderController {
	//@Autowired
	//private OrderRepository orderRepository;

	@Autowired
	OrderService orderService;
	
	@Autowired
	ItemService itemService;
	
	@RequestMapping(value={"/","/adminlogin"})
	public String adminLogin() {
		return "adminlogin";
	}
	
	// Show All Orders
	@RequestMapping("/orders")
    public String home(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Orders list.");
         model.addAttribute("orders", orderService.getAllOrders());
         return "orders";
    }
	
	@RequestMapping("/products")
    public String producthome(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Products list.");
		List<ItemEntity> item= itemService.getAllItems();
         model.addAttribute("products",item);
         return "products";
    }
	
	@RequestMapping("/addproduct")
	public String addProductPage(Model model) {
		ItemEntity item=new ItemEntity();
		model.addAttribute("item", item);
		return "newproduct"; // shud create a jsp page for adding data
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("item") ItemEntity item) {
	    itemService.saveItem(item);
	     
	    return "redirect:/";
	}
	
	



	/*
	 * @RequestMapping("/login") public String login() {
	 *
	 * return "login"; }
	 * 
	 * @RequestMapping("/register") public String register() {
	 * 
	 * return "register"; }
	 * 
	 * @PostMapping(path="/validateuser") public ModelAndView
	 * ValidateUser(@ModelAttribute OrderEntity order,BindingResult bindingResult) {
	 * OrderEntity o= orderRepository.save(order); ModelAndView m=new
	 * ModelAndView("successpage") ; m.addObject("l", o); return m; }
	 * 
	 * 
	 * @PostMapping(path="/saveOrder") public ModelAndView saveOrder(OrderEntity
	 * order) { OrderEntity o= orderRepository.save(order); ModelAndView m=new
	 * ModelAndView("successpage") ; m.addObject("l", o); return m;
	 * 
	 * }
	 */
	// Show All Products
	
	
	
	@GetMapping("/product/{model}")
	private ItemEntity getItems(@PathVariable("model") int model) {
		return itemService.getItemByModel(model);
	}
	
	/*@PutMapping("/updateproduct")
	private ItemEntity  updateItem(@RequestBody ItemEntity items) {
		 itemService.updateItem(items);
		 return items;
	}*/
	
	@DeleteMapping("/product/{model}")
	private void deleteItem(@PathVariable("model") int model) {
		 itemService.deleteItem(model);
	}

}
